package com.example.daltonrose_cs360;


public class WeightModel {
    String weight;
    String date;


    public WeightModel(String weight) {
        this.weight = weight;
    }

    public String getWeight() {
        return weight;
    }
}
